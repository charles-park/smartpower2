#define uchar unsigned char
#define uint  unsigned int
#define ulong unsigned long
#include <reg52.h>
#include <absacc.h>
#include "intrins.h"
#define iicadd 0x10;
sbit da=P1^6;
sbit cl=P1^7;
void delaym(uint time)
{
   for(;time!=0;time--)
   ;
}
void sta()	 //�������ߴ���
 {
   da=1;
   delaym(20);
   cl=1;
   delaym(20);
   da=0;
   delaym(20);
   cl=0;
   delaym(20);
 }
void stop()	//�������ߴ���
{
  da=0;
  delaym(20);
  cl=1;
  delaym(20);
  da=1;
  delaym(20);
  da=0;
  delaym(20);
  cl=0;
  delaym(20);
}
void mack()//����Ӧ��λ
{
   da=0;
   delaym(20);
   cl=1;
   delaym(20);
   cl=0;
   delaym(20);
   da=1;
}
/*
void nmack()//���ͷ�Ӧ��λ
{
  da=1;
  delaym(20);
  cl=1;
  delaym(20);
  cl=0;
  delaym(20);
  da=0;

}
bit cack() //����״̬���
{
  bit a=0;
  da=1;
  delaym(20);
  cl=1;
  if(da==0)
   {
   delaym(20);
   cl=0;
   return(0);
   }
  else
   {
   delaym(20);
   cl=0;
   return(1);
   }
}
*/
void wr1(void)//д����1
{
   da=1;
   delaym(20);
   cl=1;
   delaym(20);
   cl=0;
   delaym(20);
   da=0;
   delaym(20);
}
void wr0()//д����0
{
  da=0;
  delaym(20);
  cl=1;
  delaym(20);
  cl=0;
  delaym(20);
}
wrbyt(uchar byt)//дһ���ֽڵ����ݵ�������
{
  uchar temp=0x00;
  uchar count;
  for(count=0;count<8;count++)
    {
      if((byt<<count)&0x80)
        wr1();
      else
        wr0();
     }
}
uchar rdbyt() //�������϶�ȡһ���ֽڵ�����
{
  uchar a=0,i=0;
  for(i=0;i<8;i++)
   {
     da=1;
     cl=1;
     if(da==1)
      {
	   a=(a<<1)+1;
       cl=0;
      }
     else if(da==0)
     {
       a=a<<1;
       cl=0;
     }
   }
    return(a);
}
bit iic_testack() 
{

  bit a=0;
  da=1;
  delaym(20);
  cl=1;
  delaym(20);
  if(da==0)
   {
   delaym(20);
   cl=0;
   return(0);
   }
  else
   {
   delaym(20);
   cl=0;
   return(1);
   }
}


