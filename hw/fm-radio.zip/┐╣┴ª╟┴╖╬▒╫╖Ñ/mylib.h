#define uchar unsigned char
#define uint  unsigned int
#define num_0 13
#define num_1 4
#define num_2 8
#define num_3 12
#define num_4 2
#define num_5 6
#define num_6 10
#define num_7 1
#define num_8 5
#define num_9 9
#define next_st 7
#define prev_st 3
#define save_key 15
#define next 16
#define prev 11
#define input_key 14
#define inputfun 253
extern void ini_int(void);
extern void init(void);
extern void display_china(uchar char_[24],uchar f_cl,uchar b_cl,uchar x,uchar y,uint font_max);
extern disp_chin_st(char *st,s_x,s_y);
extern void lcddigit(unsigned int ch,x,y);
extern disp_int(uint ch,x,y);
extern void lcddigit_256(unsigned char ch,x,y);
extern disp_uchar(uchar ch,x,y);
extern void lcd_clear_n(s_y,s_y_n);
extern clean_n_line(uchar y_l);
extern void auto_search(uchar);
extern void n6100Init(void) ;
extern float frequency;
extern xdata uchar newkey;
extern void search(bit mode);
extern void radio_write(void);
extern void lcd_input(uchar *dig,x,y);
extern void set_frq(uchar *frq_m);
extern void display_char(uchar char_[18],uchar f_cl,uchar b_cl,uchar x,uchar y);
extern void lcd_clear_n(s_y,s_y_n);
extern bit rdnbyt(uchar add,uchar start,uchar num,uchar a[]);
extern bit wrnbyt(uchar add,uchar start,uchar num,uchar *k);
extern void set_stion(void);
extern void radio_read(void);
