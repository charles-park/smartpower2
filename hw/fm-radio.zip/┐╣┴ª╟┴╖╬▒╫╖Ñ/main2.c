#define uchar unsigned char
#include"reg52.h"
extern bit wrnbyt(uchar add,uchar start,uchar num,uchar a[]);
extern bit rdnbyt(uchar add,uchar num,uchar start,uchar a[]);
uchar i=2;
uchar c=0;
sbit ds1302=P1^5;
main()
{
ds1302=0;
wrnbyt(0xa0,0x00,1,&i);
rdnbyt(0xa0,0x00,1,&c);
;
}