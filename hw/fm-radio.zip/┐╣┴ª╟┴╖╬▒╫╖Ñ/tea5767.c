#include"reg52.h"
#include"24c02.h"
#include"lcm.h"
#define max_freq 108000
#define min_freq 87500
unsigned char radio_write_data[5]={0xb1,0xa0,0x20,0x11,0x00};        //Ҫд��TEA5767������
unsigned char radio_write_data1[5]={0x31,0xa0,0x20,0x11,0x00};        //Ҫд��TEA5767������
unsigned char radio_read_data[5];        //TEA5767������״̬
unsigned int default_pll=0x29c2;//0x29f9;        //Ĭ�ϴ�̨��pll,87.8MHz
unsigned int pll=0;
float frequency=0;
void get_frequency(void);
extern void sta();
extern void wrbyt(unsigned char byt);
extern bit iic_testack() ;
extern void mack();
extern void stop();
extern unsigned char rdbyt();
extern uchar frq[10];
sbit ds_1302=P1^5; 
void radio_write(void)
{
    unsigned char i;
	stop();
    sta();
    wrbyt(0xc0);        //TEA5767д��ַ
    if(!iic_testack())
    {
        for(i=0;i<5;i++)
        {
            wrbyt(radio_write_data1[i]);
            mack();
        }
    }
    stop();    
}

//��TEA5767״̬,��ת����Ƶ��
void radio_read(void)
{
    unsigned char i;
    unsigned char temp_l,temp_h;
    pll=0;
	stop();

    sta();
    wrbyt(0xc1);        //TEA5767����ַ
    if(!iic_testack())
    {
        for(i=0;i<5;i++)
        {
            radio_read_data[i]=rdbyt();
            mack();
        }
    }
    stop();
    temp_l=radio_read_data[1];
    temp_h=radio_read_data[0];
    temp_h&=0x3f;
    pll=temp_h*256+temp_l;
    get_frequency();
}

//��Ƶ�ʼ���PLL
void get_pll(void)
{
    unsigned char hlsi;
    unsigned int twpll=0;
    hlsi=radio_write_data[2]&0x10;
    if (hlsi)
        pll=(unsigned int)((float)((frequency+225)*4)/(float)32.768);    //Ƶ�ʵ�λ:k
    else
        pll=(unsigned int)((float)((frequency-225)*4)/(float)32.768);    //Ƶ�ʵ�λ:k
}
//��PLL����Ƶ��
void get_frequency(void)
{
    unsigned char hlsi;
    unsigned int npll=0;
    npll=pll;
    hlsi=radio_write_data[2]&0x10;
    if (hlsi)
        frequency=(unsigned long)((float)(npll)*(float)8.192-225);    //Ƶ�ʵ�λ:KHz
    else
        frequency=(unsigned long)((float)(npll)*(float)8.192+225);    //Ƶ�ʵ�λ:KHz
}

//�ֶ�����Ƶ��,mode=1,+0.1MHz; mode=0:-0.1MHz ,���ÿ���TEA5767������̨�����λ:SM,SUD
void search(bit mode)
{
    radio_read();        
    if(mode)
    {
        frequency+=50;
        if(frequency>max_freq)
            frequency=min_freq;
    }
    else
    {
        frequency-=50;
        if(frequency<min_freq)
            frequency=max_freq;
    }          
    EA=0;             
    get_pll();
    radio_write_data1[0]=pll/256;
    radio_write_data1[1]=pll%256;
    radio_write_data1[2]=0x20;
    radio_write_data1[3]=0x11;
    radio_write_data1[4]=0x00;
	radio_write();
	EA=1;
}
void set_frq(uchar *frq_m)
{
    EA=0;     
    frequency=(float)((*frq_m)*1000+(*(frq_m+1))*100+(*(frq_m+2))*10+(*(frq_m+3)))*100;    
	if((frequency<87500)||(frequency>108500))
	{
	EA=1;
	*frq_m=0;
	*(frq_m+1)=0;
	*(frq_m+2)=0;
	*(frq_m+3)=0;
	return;
	}
    get_pll();
    radio_write_data1[0]=pll/256;
    radio_write_data1[1]=pll%256;
    radio_write_data1[2]=0x20;
    radio_write_data1[3]=0x11;
    radio_write_data1[4]=0x00;
	radio_write();
	EA=1;
}
void auto_search(uchar dec)
{
int k=0;
unsigned char aa[6]={0}; 
ds_1302=0;
radio_write();
  if(dec)
  {
  while(frequency<max_freq)
  {   
    get_pll();
    radio_write_data1[0]=pll/256;
    radio_write_data1[1]=pll%256;
    radio_write_data1[2]=0xA0;
    radio_write_data1[3]=0x11;
    radio_write_data1[4]=0x00;
    radio_write_data1[0]|=0x40;
	radio_write();
    for(k=0;k<20000;k++)
	EA=0;
    radio_read();
    if((radio_read_data[0]&0x80))
    {
    EA=0;  
    frequency+=50;
    return; 
    }
  }
  frequency=min_freq;
  }
  else
  {
  while(frequency>min_freq)
  {   
    get_pll();
    radio_write_data1[0]=pll/256;
    radio_write_data1[1]=pll%256;
    radio_write_data1[2]=0x20;
    radio_write_data1[3]=0x11;
    radio_write_data1[4]=0x00;
    radio_write_data1[0]|=0x40;
	radio_write();
    for(k=0;k<20000;k++)
	EA=0;
    radio_read();
    if((radio_read_data[0]&0x80))
    {
    EA=0;  
    frequency-=50;
    return; 
    }
  }
 frequency=max_freq;
 }
}



