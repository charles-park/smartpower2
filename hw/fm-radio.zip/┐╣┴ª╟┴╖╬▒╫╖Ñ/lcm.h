

#define uchar unsigned char
#define uint unsigned int
#define uint8_t uchar
void lcd_clear(void);
void lcd_init(void);
void delayms(uint);
void lcd_setxy(uchar,uchar,uchar,uchar);
void lcd_send(uchar,uchar);
void lcd_put_pixel(uchar,uchar,uchar);
void lcd_gimage(void);
void lcd_writechinesestring(uint8_t num, uint8_t x, uint8_t y);
void lcd_write(uint8_t i, uint8_t x, uint8_t y);
void display_char(uchar char_[24],uchar f_cl,uchar b_cl,uchar x,uchar y);
void lcddigit(unsigned int ch,x,y);
void display_china(uchar char_[24],uchar f_cl,uchar b_cl,uchar x,uchar y,uint font_max);
void lcd_clear_n(s_y,s_y_n);
void show_time(void);
void n6100Init(void) ;
uchar key_seach(void);
extern void wridata(uchar ch);
extern void wricmd(uchar ch);
extern void cls(uchar ch) ;
extern void initlcd(void);
extern void write_word(char wd,uchar x,uchar y);
extern void write_str(char *p,uchar x,uchar y);
extern void lcddigit(unsigned int ch,x,y);
extern void lcddigit_256(unsigned char ch,x,y);
extern void lcddigit(unsigned int ch,x,y);
extern void cls_line(uchar ch); 
#define get(val,bitn) (val&(1<<bitn))        




